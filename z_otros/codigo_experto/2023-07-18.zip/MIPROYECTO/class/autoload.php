<?php


class autoload{
    
    static public function autocarga($clase){
        $class = array();
        $class['productos'] = "../class/productos.php";
        $class['categorias'] = "../class/categorias.php";
        $class['base_datos'] = "../class/base_datos.php";        
        
        if (isset($class[$clase])){
            include $class[$clase];
        } else {
            echo "NO SE DEFINIO LA CLASE ".$clase;
            die();
        }        
    }    
}

spl_autoload_register("autoload::autocarga");